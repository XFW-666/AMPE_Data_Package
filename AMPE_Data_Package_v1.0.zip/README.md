# Risques de maladies professionnelles chez les étudiants en formation professionnelle pendant les stages obligatoires en industrie manufacturière

## Données de la revue systématique

Ce dépôt contient l'intégralité des données associées à la revue systématique :

> Xue F, Zhao J, Zhang R, Han P. Risques de maladies professionnelles chez les étudiants en formation professionnelle pendant les stages obligatoires en industrie manufacturière : une revue systématique de la littérature internationale (1990–2026). *Archives des Maladies Professionnelles et de l'Environnement*.

## Contenu

| Fichier | Description |
|---------|-------------|
| `data/search_strategy.csv` | Stratégie de recherche documentaire (8 requêtes, rendements) |
| `data/prisma_counts.json` | Décomptes du diagramme de flux PRISMA 2020 |
| `data/included_studies.csv` | Caractéristiques des 244 rapports inclus |
| `data/quality_assessment.csv` | Grille d'évaluation de la qualité (8 items, 49 études quantitatives) |
| `data/quantitative_extraction.csv` | 51 estimations quantitatives extraites et revérifiées |
| `data/references.csv` | Liste bibliographique (98 références, format Vancouver) |
| `data/country_distribution.csv` | Répartition géographique des rapports |
| `figures/` | 8 figures haute résolution (300+ dpi) + vecteurs PDF |

## Méthodologie

Recherche documentaire exécutée les 13–14 septembre 2026 dans PubMed/MEDLINE, OpenAlex et Crossref (bornes 1990–2026, langues anglais et français), conformément aux recommandations PRISMA 2020. La qualité méthodologique a été évaluée au moyen d'une grille à huit items adaptée de l'échelle de Newcastle-Ottawa. Aucune méta-analyse n'a été tentée en raison de l'hétérogénéité des populations, dessins et indicateurs.

## Licence

Les données sont publiées sous licence [Creative Commons Attribution 4.0 International](https://creativecommons.org/licenses/by/4.0/).
